package com.example.conseils.model

data class Conseil(
    val jour: Int,
    val titre: String,
    val description: String,
    val imageRes: Int
)
